<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Rumah Tangga</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <!-- Font Roboto -->
    <link rel="stylesheet" href="assets/css/userdashboard.css">
        <!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- Font Awesome for Icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>

<body>
    <?php include 'assets/components/header.php'; ?>

    <!-- slider start -->
    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="assets/img/slider1.jpg" class="d-block w-100" alt="..." style="height: 50vh;">
            </div>
            <div class="carousel-item">
                <img src="assets/img/slider2.jpg" class="d-block w-100" alt="..." style="height: 50vh;">
            </div>
            <div class="carousel-item">
                <img src="assets/img/slider3.jpg" class="d-block w-100" alt="..." style="height: 50vh;">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    <!-- slider end -->

        <!-- konten Bank Sampah start -->
        <section class="konten1">
        <div class="container">
            <div class="row">
                <div class="col-8">
                    <h2>Apa itu Bank Sampah?</h2>
                    <p class="lead">Bank Sampah adalah sebuah program pengelolaan sampah yang bertujuan untuk mendaur ulang sampah dengan cara memanfaatkan barang-barang bekas yang masih bernilai ekonomis. Konsep ini bekerja dengan cara menabung sampah yang dapat diolah kembali, seperti plastik, kertas, dan logam. Melalui Bank Sampah, masyarakat didorong untuk lebih peduli terhadap lingkungan dan memanfaatkan sampah secara bijak demi menjaga kebersihan dan kelestarian lingkungan.</p>
                    <p>Selain sebagai solusi pengelolaan sampah, Bank Sampah juga memberikan manfaat ekonomi bagi masyarakat, karena sampah yang dikumpulkan dapat ditukar dengan uang atau barang kebutuhan sehari-hari.</p>
                </div>
            </div>

            <!-- Tambahan Konten -->
            <div class="row mt-5">
                <div class="col-12">
                    <h3>Cara Kerja Bank Sampah</h3>
                    <ol>
                        <li>Masyarakat mengumpulkan sampah yang bisa didaur ulang seperti plastik, kertas, dan logam.</li>
                        <li>Sampah yang sudah dipilah disetor ke Bank Sampah terdekat.</li>
                        <li>Sampah tersebut ditimbang dan dinilai berdasarkan jenis dan beratnya.</li>
                        <li>Masyarakat mendapatkan buku tabungan atau aplikasi untuk mencatat saldo dari sampah yang dikumpulkan.</li>
                        <li>Saldo tersebut dapat ditukar dengan uang, sembako, atau keperluan lainnya.</li>
                    </ol>
                </div>
            </div>

            <div class="row mt-5">
                <div class="col-12">
                    <h3>Manfaat Bank Sampah</h3>
                    <ul>
                        <li><strong>Mengurangi Volume Sampah:</strong> Bank Sampah membantu mengurangi sampah yang berakhir di tempat pembuangan akhir (TPA).</li>
                        <li><strong>Meningkatkan Pendapatan:</strong> Sampah yang biasanya tidak berguna dapat diolah dan ditukar dengan uang atau kebutuhan rumah tangga.</li>
                        <li><strong>Menciptakan Lapangan Kerja:</strong> Bank Sampah juga menciptakan peluang pekerjaan baru untuk pengelolaan sampah.</li>
                        <li><strong>Mendorong Kesadaran Lingkungan:</strong> Masyarakat diajak untuk lebih peduli pada lingkungan dengan memilah dan mendaur ulang sampah.</li>
                    </ul>
                </div>
            </div>

            <!-- Kisah Sukses Bank Sampah -->
            <div class="row mt-5">
                <div class="col-12">
                    <h3>Kisah Sukses: "Mengubah Sampah Menjadi Emas"</h3>
                    <p>Pak Suryadi, seorang warga yang tinggal di Jakarta Barat, telah merasakan manfaat dari Bank Sampah. Awalnya, dia hanya sekadar menyetor sampah plastik dari rumah tangganya. Namun, setelah mengikuti program lebih lanjut, dia mulai mengumpulkan sampah dari tetangganya dan sekarang telah memiliki usaha daur ulang sendiri. Dari keuntungan yang diperoleh, dia mampu membiayai pendidikan anak-anaknya hingga ke perguruan tinggi.</p>
                </div>
            </div>
            <div>
                <button type="button" class="btn btn-success"><a href="?mod=jual" style="color: white;">Mulai Menjual
                        Sampah</button>
            </div>
        </div>
    </section>
    <!-- konten Bank Sampah end -->

    <?php include 'assets/components/footer.php'; ?>


    <!-- Scripts for Bootstrap and Font Awesome -->
    <script src="https://kit.fontawesome.com/0b79c15f2d.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
        crossorigin="anonymous"></script>
</body>

</html>