<?php

header('location:page.php?mod=home');

?>