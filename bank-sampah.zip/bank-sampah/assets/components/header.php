
<style>
/* General navbar styling */
.navbar {
    background-color: #1a1a1a; /* Background warna sesuai tema */
    position: sticky;
    top: 0;
    z-index: 1000;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.3); /* Shadow di bawah navbar */
    height: 10vh; /* Tinggi navbar default */
}

/* Styling for links and brand text */
.navbar-light .navbar-nav .nav-link,
.navbar-light .navbar-brand {
    color: #fff; /* Warna putih default untuk teks */
}

/* Hover effect on links */
.navbar-light .navbar-nav .nav-link:hover,
.navbar-light .navbar-brand:hover {
    color: #63bb65; /* Warna hijau untuk hover */
}

/* Right-align the menu */
.navbar-nav {
    margin-left: auto;
}

/* Navbar links styling */
.navbar-nav .nav-item {
    margin-right: 20px;
}

.navbar-nav .nav-link {
    display: flex;
    align-items: center;
    justify-content: center; /* Centering the icons vertically and horizontally */
    text-align: center;
    width: 100%; /* Full width for items to ensure centering */
}

.navbar-nav .nav-link i {
    margin-right: 8px;
}

/* Fixing dropdown height and centering content */
.navbar-collapse {
    background-color: #1a1a1a; /* Same background as navbar */
    padding: 0; /* Remove any extra padding */
    margin: 0; /* Remove margin */
}

.navbar-collapse.show {
    height: auto; /* Height adjusts when shown */
    background-color: #1a1a1a; /* Ensures consistent theme */
}

.navbar-collapse .navbar-nav {
    width: 100%; /* Full width for centering */
    display: flex;
    flex-direction: column;
    justify-content: center; /* Center items vertically */
}

/* Remove the default spacing in the collapse area */
.nav-item {
    width: 100%;
}

/* Fixing the mobile toggle button */
.navbar-light .navbar-toggler {
    border-color: rgba(255, 255, 255, 0.1);
}

.navbar-light .navbar-toggler-icon {
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3E%3Cpath stroke='rgba%2863, 187, 101, 0.5%29' stroke-width='2' stroke-linecap='round' stroke-miterlimit='10' d='M4 7h22M4 15h22M4 23h22'/%3E%3C/svg%3E");
}

</style>
<nav class="navbar navbar-expand-lg navbar-light">
    <a class="navbar-brand" href="#">
        <img src="assets/img/logo.png" style="width: 8vh;" alt="Logo">
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item active">
                <a class="nav-link" style="color: #63bb65" href="?mod=users"><i class="fas fa-house"></i> Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?mod=riwayat"><i class="fas fa-clock-rotate-left"></i> History</a>
            </li>        
            <li class="nav-item">
                <a class="nav-link" href="?mod=jual"><i class="fas fa-tags"></i> Jual Sampah</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?mod=profile"><i class="fas fa-user"></i> Profile</a>
            </li>
        </ul>
    </div>
</nav>
